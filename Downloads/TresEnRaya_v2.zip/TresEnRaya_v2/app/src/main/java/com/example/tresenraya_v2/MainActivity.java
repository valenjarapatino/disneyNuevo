 package com.example.tresenraya_v2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.sql.Array;

 public class MainActivity extends AppCompatActivity {

    TextView textovictoria;
    Integer[] botones;
    int [] tablero = new int[]{
            0, 0, 0,
            0, 0, 0,
            0, 0, 0
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textovictoria = (TextView) findViewById(R.id.textovictorio);
        textovictoria.setVisibility(View.INVISIBLE);

        botones  = new Integer[]{
                R.id.buttonb1, R.id.b2, R.id.b3,
                R.id.b4, R.id.b5, R.id.b6,
                R.id.b7, R.id.b8, R.id.b9,
        };
    }
    public void ponerFicha(View v){
        int numBoton = Arrays.osList(botones).indexOf(v.getId());
        v.setBackgroundResource(R.drawable.ana15);
        tablero[numBoton] = 1;
    }
}